/**
 * QA Test Script for TOM Operating System - MS365 Architecture Prototype
 * Tests HTML structure, JavaScript logic, and deployment readiness.
 * Run with: node qa-test.js
 */

const fs = require('fs');
const path = require('path');

let passed = 0;
let failed = 0;
const failures = [];

function test(name, condition) {
  if (condition) {
    passed++;
    console.log(`  PASS: ${name}`);
  } else {
    failed++;
    failures.push(name);
    console.log(`  FAIL: ${name}`);
  }
}

// ============================================================
// 1. FILE STRUCTURE TESTS
// ============================================================
console.log('\n=== File Structure Tests ===');

const publicDir = path.join(__dirname, 'public');
const indexPath = path.join(publicDir, 'index.html');
const netlifyToml = path.join(__dirname, 'netlify.toml');
const packageJson = path.join(__dirname, 'package.json');
test('public/ directory exists', fs.existsSync(publicDir));
test('public/index.html exists', fs.existsSync(indexPath));
test('netlify.toml exists', fs.existsSync(netlifyToml));
test('package.json exists', fs.existsSync(packageJson));

// ============================================================
// 2. NETLIFY CONFIG TESTS
// ============================================================
console.log('\n=== Netlify Configuration Tests ===');

const tomlContent = fs.readFileSync(netlifyToml, 'utf-8');
test('netlify.toml has publish directory set to "public"', tomlContent.includes('publish = "public"'));
test('netlify.toml has build command', tomlContent.includes('[build]'));
test('netlify.toml has security headers', tomlContent.includes('X-Frame-Options'));
test('netlify.toml has cache headers for static assets', tomlContent.includes('max-age=31536000'));
test('netlify.toml has SPA redirect rule', tomlContent.includes('from = "/*"') && tomlContent.includes('status = 200'));

// ============================================================
// 3. HTML STRUCTURE TESTS
// ============================================================
console.log('\n=== HTML Structure Tests ===');

const html = fs.readFileSync(indexPath, 'utf-8');

test('Has DOCTYPE declaration', html.trimStart().startsWith('<!DOCTYPE html>'));
test('Has lang attribute on html tag', html.includes('<html lang="en">'));
test('Has meta charset UTF-8', html.includes('charset="UTF-8"'));
test('Has meta viewport for responsive design', html.includes('viewport'));
test('Has title element', html.includes('<title>'));
test('Has closing </html> tag', html.includes('</html>'));
test('Has closing </body> tag', html.includes('</body>'));
test('Has closing </head> tag', html.includes('</head>'));

// ============================================================
// 4. CDN DEPENDENCY TESTS
// ============================================================
console.log('\n=== CDN Dependency Tests ===');

test('Loads Tailwind CSS from CDN', html.includes('cdn.tailwindcss.com'));
test('Loads Chart.js from CDN', html.includes('chart.js'));
test('Loads Google Fonts (Segoe UI)', html.includes('fonts.googleapis.com'));
test('Uses HTTPS for Tailwind', html.includes('https://cdn.tailwindcss.com'));
test('Uses HTTPS for Chart.js', html.includes('https://cdn.jsdelivr.net'));

// ============================================================
// 5. VIEW SECTION TESTS
// ============================================================
console.log('\n=== View Section Tests ===');

const views = [
  'view-dashboard',
  'view-registers',
  'view-register-icp',
  'view-planner',
  'view-automations',
  'view-performance',
  'view-architecture'
];

views.forEach(view => {
  test(`View "${view}" exists in HTML`, html.includes(`id="${view}"`));
});

test('Dashboard is visible by default (no hidden class)', !html.match(/id="view-dashboard"[^>]*class="[^"]*hidden/));
test('Other views are hidden by default', html.includes('id="view-architecture" class="view-section hidden"'));

// ============================================================
// 6. NAVIGATION TESTS
// ============================================================
console.log('\n=== Navigation Tests ===');

const navItems = ['nav-dashboard', 'nav-registers', 'nav-planner', 'nav-automations', 'nav-performance', 'nav-architecture'];
navItems.forEach(nav => {
  test(`Navigation item "${nav}" exists`, html.includes(`id="${nav}"`));
});

test('switchView function is defined', html.includes('function switchView(viewName)'));
test('Dashboard nav has active-nav class initially', html.includes('id="nav-dashboard" class="sidebar-item active-nav'));

// ============================================================
// 7. DATA STORE TESTS
// ============================================================
console.log('\n=== Data Store Tests ===');

test('tomData object is defined', html.includes('let tomData'));
test('ICP data array exists with items', html.includes("icp: ["));
test('Activities data array exists', html.includes("activities: ["));
test('Has at least 4 ICP items', (html.match(/id: 'ICP-/g) || []).length >= 4);

// ============================================================
// 8. INTERACTIVE FEATURE TESTS
// ============================================================
console.log('\n=== Interactive Feature Tests ===');

test('Intake modal exists', html.includes('id="intake-modal"'));
test('openIntakeModal function defined', html.includes('function openIntakeModal'));
test('closeIntakeModal function defined', html.includes('function closeIntakeModal'));
test('submitIntake function defined', html.includes('function submitIntake'));
test('Modal form has required fields (title)', html.includes('id="intake-title"'));
test('Modal form has required fields (requestor)', html.includes('id="intake-requestor"'));
test('Modal form has required fields (priority)', html.includes('id="intake-priority"'));

// Drag and drop
test('allowDrop function defined', html.includes('function allowDrop'));
test('drag function defined', html.includes('function drag'));
test('drop function defined', html.includes('function drop'));
test('Kanban columns have ondrop handlers', html.includes('ondrop="drop(event)"'));
test('Kanban columns have ondragover handlers', html.includes('ondragover="allowDrop(event)"'));

// Charts
test('initCharts function defined', html.includes('function initCharts'));
test('Chart canvas: timeliness', html.includes('id="chart-timeliness"'));
test('Chart canvas: exceptions', html.includes('id="chart-exceptions"'));
test('Chart canvas: controls', html.includes('id="chart-controls"'));

// Automation console
test('simulateAutomation function defined', html.includes('function simulateAutomation'));
test('Automation log container exists', html.includes('id="automation-log"'));
test('Test ICP Flow button exists', html.includes("simulateAutomation('intake')"));
test('Test Approval button exists', html.includes("simulateAutomation('approval')"));
test('Test Evidence button exists', html.includes("simulateAutomation('evidence')"));

// ============================================================
// 9. RENDERING FUNCTION TESTS
// ============================================================
console.log('\n=== Rendering Function Tests ===');

test('renderDashboard function defined', html.includes('function renderDashboard'));
test('renderRegisters function defined', html.includes('function renderRegisters'));
test('updateCounts function defined', html.includes('function updateCounts'));
test('DOMContentLoaded listener initializes app', html.includes("document.addEventListener('DOMContentLoaded'"));

// ============================================================
// 10. KANBAN BOARD STRUCTURE TESTS
// ============================================================
console.log('\n=== Kanban Board Tests ===');

const kanbanCols = ['col-not-started', 'col-progress', 'col-review', 'col-complete'];
kanbanCols.forEach(col => {
  test(`Kanban column "${col}" exists`, html.includes(`id="${col}"`));
});

const kanbanCounts = ['count-not-started', 'count-progress', 'count-review', 'count-complete'];
kanbanCounts.forEach(count => {
  test(`Count badge "${count}" exists`, html.includes(`id="${count}"`));
});

test('At least one draggable task exists', html.includes('draggable="true"'));

// ============================================================
// 11. METRIC ELEMENTS TESTS
// ============================================================
console.log('\n=== Metric Elements Tests ===');

const metrics = ['metric-open-items', 'metric-risks', 'metric-completion', 'metric-pending'];
metrics.forEach(metric => {
  test(`Metric element "${metric}" exists`, html.includes(`id="${metric}"`));
});

// ============================================================
// 12. SECURITY/XSS CHECK
// ============================================================
console.log('\n=== Security Tests ===');

// Check that form data is assigned to textContent or .value, not innerHTML directly from user input
test('Form submission uses controlled data (no raw innerHTML injection from user input)',
  html.includes("document.getElementById('intake-title').value") &&
  html.includes("document.getElementById('intake-requestor').value"));

// XSS protection: escapeHtml helper must exist and be used in rendering
test('escapeHtml() function is defined for XSS prevention',
  html.includes('function escapeHtml('));
test('ICP table renders title through escapeHtml()',
  html.includes('escapeHtml(item.title)'));
test('ICP table renders requestor through escapeHtml()',
  html.includes('escapeHtml(item.requestor)'));
test('Activity stream renders text through escapeHtml()',
  html.includes('escapeHtml(act.text)'));

// ============================================================
// 13. CSS STYLING TESTS
// ============================================================
console.log('\n=== CSS Tests ===');

test('MS365 brand colors defined', html.includes('.ms-teams') && html.includes('.ms-sharepoint'));
test('Sidebar hover styles defined', html.includes('.sidebar-item:hover'));
test('Active nav styles defined', html.includes('.active-nav'));
test('Card styles defined', html.includes('.card {'));
test('Kanban column styles defined', html.includes('.kanban-col'));
test('Architecture map grid defined', html.includes('.architecture-map'));

// ============================================================
// 14. MOBILE CONTENT PARITY TESTS
// ============================================================
console.log('\n=== Mobile Content Parity Tests ===');

// Extract the CSS block for body.mobile-mode rules
const mobileCSS = html.match(/body\.mobile-mode[\s\S]*?<\/style>/)?.[0] || '';

// --- Banner text must NOT be hidden ---
// The migration banner's last span contains the MS365 stack description.
// It must remain visible (no display:none) so mobile users see it.
const bannerLastSpanRule = html.match(/body\.mobile-mode\s+\.migration-banner\s+span:last-child\s*\{([^}]+)\}/);
test('Banner stack description is NOT hidden in mobile (no display:none)',
  bannerLastSpanRule && !bannerLastSpanRule[1].includes('display') || !bannerLastSpanRule[1].includes('none'));
test('Banner stack description has compact font-size in mobile',
  bannerLastSpanRule && /font-size:\s*[\d.]+rem/.test(bannerLastSpanRule[1]));

// --- MS equiv badge must NOT be hidden ---
// The .ms-equiv-badge shows "Replaces: Microsoft Teams..." context.
const msEquivRule = html.match(/body\.mobile-mode\s+\.ms-equiv-badge\s*\{([^}]+)\}/);
test('MS equiv badge is NOT hidden in mobile (no display:none)',
  msEquivRule && !msEquivRule[1].includes('display: none') && !msEquivRule[1].includes('display:none'));
test('MS equiv badge has compact styling in mobile',
  msEquivRule && /font-size:\s*[\d.]+rem/.test(msEquivRule[1]));
test('MS equiv badge uses text-overflow ellipsis for space efficiency',
  msEquivRule && msEquivRule[1].includes('text-overflow'));

// --- Intake button text must NOT be hidden ---
// The .intake-btn-text shows "New ICP Intake" label.
const intakeTextRule = html.match(/body\.mobile-mode\s+\.top-bar-actions\s+\.intake-btn-text\s*\{([^}]+)\}/);
test('Intake button text is NOT hidden in mobile (no display:none)',
  intakeTextRule && !intakeTextRule[1].includes('display: none') && !intakeTextRule[1].includes('display:none'));
test('Intake button text has compact font-size in mobile',
  intakeTextRule && /font-size:\s*[\d.]+rem/.test(intakeTextRule[1]));

// --- Intake button badge must NOT be hidden ---
// The .intake-btn-badge shows "→ List item" contextual hint.
const intakeBadgeRule = html.match(/body\.mobile-mode\s+\.top-bar-actions\s+\.intake-btn-badge\s*\{([^}]+)\}/);
test('Intake button badge is NOT hidden in mobile (no display:none)',
  intakeBadgeRule && !intakeBadgeRule[1].includes('display: none') && !intakeBadgeRule[1].includes('display:none'));
test('Intake button badge has compact font-size in mobile',
  intakeBadgeRule && /font-size:\s*[\d.]+rem/.test(intakeBadgeRule[1]));

// --- Mobile view toggle still works ---
test('setViewMode function is defined', html.includes('function setViewMode(mode)'));
test('View mode toggle buttons exist', html.includes('id="toggle-desktop"') && html.includes('id="toggle-mobile"'));
test('Mobile mode class toggle is intact', html.includes("body.classList.add('mobile-mode')") && html.includes("body.classList.remove('mobile-mode')"));

// --- Verify no other display:none rules hide content in mobile ---
// Allowed: hamburger-btn (shown), sidebar-overlay (shown), sidebar-close-btn (shown)
// swimlane-arrow is acceptable (decorative, no HTML elements use it)
const mobileDisplayNoneRules = html.match(/body\.mobile-mode[^{]*\{[^}]*display:\s*none[^}]*\}/g) || [];
const allowedHiddenClasses = ['swimlane-arrow']; // decorative only, no HTML uses it
const unexpectedHidden = mobileDisplayNoneRules.filter(rule => {
  return !allowedHiddenClasses.some(cls => rule.includes(cls));
});
test('No unexpected display:none rules hiding content in mobile mode',
  unexpectedHidden.length === 0);

// --- Content elements still exist in HTML (not removed) ---
test('Banner stack text span exists in HTML',
  html.includes('Simulating MS365 stack'));
test('MS equiv badge element exists in HTML',
  html.includes('ms-equiv-badge'));
test('Intake button text element exists in HTML',
  html.includes('intake-btn-text'));
test('Intake button badge element exists in HTML',
  html.includes('intake-btn-badge'));

// --- public/index.html matches index.html (deploy parity) ---
const rootHtml = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf-8');
test('public/index.html matches root index.html (deploy sync)',
  html === rootHtml);

// ============================================================
// 15. PACKAGE.JSON TESTS
// ============================================================
console.log('\n=== Package.json Tests ===');

const pkg = JSON.parse(fs.readFileSync(packageJson, 'utf-8'));
test('package.json has name', typeof pkg.name === 'string' && pkg.name.length > 0);
test('package.json has version', typeof pkg.version === 'string');
test('package.json has build script', typeof pkg.scripts?.build === 'string');
test('package.json is marked private', pkg.private === true);

// ============================================================
// RESULTS
// ============================================================
console.log('\n' + '='.repeat(50));
console.log(`RESULTS: ${passed} passed, ${failed} failed, ${passed + failed} total`);

if (failures.length > 0) {
  console.log('\nFailed tests:');
  failures.forEach(f => console.log(`  - ${f}`));
}

console.log('='.repeat(50));
process.exit(failed > 0 ? 1 : 0);
